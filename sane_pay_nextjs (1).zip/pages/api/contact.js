import nodemailer from 'nodemailer';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({error: 'method_not_allowed'});
  const { name, email, message } = req.body || {};
  if (!message || !email) return res.status(400).json({error: 'missing_fields'});

  const smtpUser = process.env.SMTP_USER;
  const smtpPass = process.env.SMTP_PASS;
  const smtpHost = process.env.SMTP_HOST || 'smtp.gmail.com';
  const smtpPort = process.env.SMTP_PORT || 587;
  const to = process.env.CUSTOMER_SERVICE_EMAIL || process.env.NEXT_PUBLIC_CUSTOMER_SERVICE_EMAIL || 'santiagocolam3@gmail.com';
  const cc = process.env.OWNER_EMAIL || process.env.NEXT_PUBLIC_OWNER_EMAIL || 'solomonazubuike11@gmail.com';

  try {
    const transporter = nodemailer.createTransport({
      host: smtpHost,
      port: Number(smtpPort),
      secure: false,
      auth: { user: smtpUser, pass: smtpPass },
    });

    await transporter.sendMail({
      from: `${name || 'Website visitor'} <${email}>`,
      to,
      cc,
      subject: `Sane-Pay support message from ${name || email}`,
      text: `From: ${email}\nName: ${name}\n\n${message}`,
    });

    return res.json({ok:true});
  } catch (err) {
    console.error(err);
    return res.status(500).json({ok:false, error: 'email_error'});
  }
}
