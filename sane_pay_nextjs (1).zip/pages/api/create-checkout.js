import Stripe from 'stripe';
import fetch from 'node-fetch';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({error:'method_not_allowed'});
  const { gateway, amount } = req.body || {};
  const baseUrl = process.env.BASE_URL || (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : `http://localhost:3000`);

  if (!gateway) return res.status(400).json({error:'missing_gateway'});

  try {
    if (gateway === 'stripe') {
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        mode: 'payment',
        line_items: [{ price_data: { currency: 'ngn', product_data: { name: 'Sane-Pay purchase' }, unit_amount: amount }, quantity: 1 }],
        success_url: `${baseUrl}/?status=success`,
        cancel_url: `${baseUrl}/?status=cancel`,
      });
      return res.json({url: session.url});
    }

    if (gateway === 'paystack') {
      // Paystack expects amount in kobo; multiply by 100
      const init = await fetch('https://api.paystack.co/transaction/initialize', {
        method: 'POST',
        headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`, 'Content-Type':'application/json' },
        body: JSON.stringify({ email: process.env.CUSTOMER_SERVICE_EMAIL, amount: (amount*100) })
      }).then(r=>r.json());
      if (!init.status) return res.status(500).json({error:'paystack_init_failed', details:init});
      return res.json({url: init.data.authorization_url});
    }

    if (gateway === 'flutterwave') {
      const payload = {
        tx_ref: `sane-${Date.now()}`,
        amount,
        currency: 'NGN',
        redirect_url: `${baseUrl}/?status=success`,
        customer: { email: process.env.CUSTOMER_SERVICE_EMAIL, name: 'Customer' },
      };
      const init = await fetch('https://api.flutterwave.com/v3/payments', {
        method:'POST',
        headers:{ Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}`, 'Content-Type':'application/json' },
        body: JSON.stringify(payload)
      }).then(r=>r.json());
      if (!init.status) return res.status(500).json({error:'flutterwave_init_failed', details:init});
      return res.json({url: init.data.link});
    }

    return res.status(400).json({error:'unsupported_gateway'});
  } catch (err) {
    console.error(err);
    return res.status(500).json({error:'server_error', details: String(err)});
  }
}
