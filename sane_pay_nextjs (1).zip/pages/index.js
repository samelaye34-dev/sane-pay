import React, {useState} from 'react';

const CONFIG = {
  COMPANY_NAME: 'Sane-Pay',
  CUSTOMER_SERVICE_EMAIL: process.env.NEXT_PUBLIC_CUSTOMER_SERVICE_EMAIL || 'santiagocolam3@gmail.com',
  OWNER_EMAIL: process.env.NEXT_PUBLIC_OWNER_EMAIL || 'solomonazubuike11@gmail.com',
  CUSTOMER_SERVICE_PHONE: process.env.NEXT_PUBLIC_CUSTOMER_SERVICE_PHONE || '+2349039950429',
};

export default function Home() {
  return (
    <div className="min-h-screen font-sans">
      <header className="bg-white shadow">
        <div className="max-w-6xl mx-auto px-4 py-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">{CONFIG.COMPANY_NAME}</h1>
            <p className="text-sm text-gray-500">Pay bills • Buy airtime • Gift cards • Fast & secure</p>
          </div>
          <div className="text-right">
            <div className="text-sm">Customer Service: <a href={`tel:${CONFIG.CUSTOMER_SERVICE_PHONE}`} className="font-medium">{CONFIG.CUSTOMER_SERVICE_PHONE}</a></div>
            <div className="text-sm">Support: <a href={`mailto:${CONFIG.CUSTOMER_SERVICE_EMAIL}`} className="font-medium">{CONFIG.CUSTOMER_SERVICE_EMAIL}</a></div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-6">
        <section className="bg-gradient-to-r from-sky-50 to-white rounded-lg p-8 mb-8">
          <h2 className="text-3xl font-bold mb-2">Fast. Secure. Reliable payments — meet Sane-Pay</h2>
          <p className="text-gray-700 mb-4">Pay bills, buy airtime, gift cards, and more. Built for Nigeria and international users.</p>
          <div className="flex gap-3">
            <a className="px-4 py-2 bg-sky-600 text-white rounded shadow" href="#products">Get Started</a>
            <a className="px-4 py-2 border rounded" href={`mailto:${CONFIG.CUSTOMER_SERVICE_EMAIL}`}>Contact Support</a>
          </div>
        </section>

        <section id="products" className="bg-white rounded p-6 mb-8 shadow-sm">
          <h3 className="text-xl font-bold mb-4">Services</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Product name="Airtime Top-up" priceText="From ₦100"/>
            <Product name="Data Bundles" priceText="Varies by network"/>
            <Product name="Gift Cards" priceText="Multiple brands"/>
          </div>

          <div className="mt-6">
            <h4 className="font-semibold mb-2">Quick Checkout (demo)</h4>
            <p className="text-sm text-gray-600 mb-3">Click a gateway to create a demo checkout session. You must set real API keys in the project environment to accept payments.</p>
            <div className="flex gap-2">
              <GatewayButton gateway="stripe">Pay with Stripe</GatewayButton>
              <GatewayButton gateway="paystack">Pay with Paystack</GatewayButton>
              <GatewayButton gateway="flutterwave">Pay with Flutterwave</GatewayButton>
            </div>
          </div>
        </section>

        <ContactForm />

      </main>

      <footer className="bg-white mt-12 border-t">
        <div className="max-w-6xl mx-auto p-6 flex justify-between text-sm text-gray-600">
          <div>© {new Date().getFullYear()} {CONFIG.COMPANY_NAME}. All rights reserved.</div>
          <div>Owner: Solomon Azubuike • <a href={`mailto:${CONFIG.OWNER_EMAIL}`}>{CONFIG.OWNER_EMAIL}</a></div>
        </div>
      </footer>
    </div>
  );
}

function Product({name, priceText}){
  return (
    <div className="border rounded p-4">
      <h5 className="font-semibold">{name}</h5>
      <div className="text-gray-600 mt-2">{priceText}</div>
      <div className="mt-4">
        <input defaultValue="100" className="border rounded p-2 w-full" />
      </div>
    </div>
  )
}

function GatewayButton({gateway, children}){
  const [loading, setLoading] = useState(false);
  async function handle(){
    setLoading(true);
    try{
      const res = await fetch('/api/create-checkout', {
        method: 'POST', headers: {'content-type':'application/json'},
        body: JSON.stringify({gateway, amount:500})
      });
      const j = await res.json();
      if(j.url) window.open(j.url, '_blank');
      else alert('No URL returned: ' + (j.error || JSON.stringify(j)));
    }catch(e){
      alert('Network error creating checkout.');
    }finally{ setLoading(false); }
  }
  return <button onClick={handle} disabled={loading} className="px-3 py-2 border rounded">{loading ? 'Processing...' : children}</button>
}

function ContactForm(){
  const [state, setState] = useState({name:'', email:'', message:'', sending:false, result:''});
  async function submit(e){
    e.preventDefault();
    setState(s=>({...s, sending:true, result:''}));
    try{
      const res = await fetch('/api/contact', {method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({name:state.name, email:state.email, message:state.message})});
      const j = await res.json();
      setState(s=>({...s, sending:false, result: j.ok ? 'Message sent — support will reply shortly.' : 'Failed to send message.'}));
    }catch(err){
      setState(s=>({...s, sending:false, result:'Network error: could not send.'}));
    }
  }

  return (
    <section id="contact" className="bg-white rounded p-6 shadow-sm">
      <h3 className="text-xl font-bold mb-3">Contact / Support</h3>
      <p className="text-sm text-gray-600 mb-3">Email: <a href={`mailto:${CONFIG.CUSTOMER_SERVICE_EMAIL}`}>{CONFIG.CUSTOMER_SERVICE_EMAIL}</a> • Phone: <a href={`tel:${CONFIG.CUSTOMER_SERVICE_PHONE}`}>{CONFIG.CUSTOMER_SERVICE_PHONE}</a></p>

      <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <input placeholder="Your name" value={state.name} onChange={e=>setState({...state, name:e.target.value})} className="border rounded p-2" />
        <input placeholder="Your email" value={state.email} onChange={e=>setState({...state, email:e.target.value})} className="border rounded p-2" />
        <textarea placeholder="Message" value={state.message} onChange={e=>setState({...state, message:e.target.value})} className="border rounded p-2 md:col-span-2" />
        <div className="md:col-span-2 flex items-center gap-3">
          <button className="px-4 py-2 bg-sky-600 text-white rounded" disabled={state.sending}>{state.sending ? 'Sending...' : 'Send Message'}</button>
          <div className="text-sm text-gray-600">{state.result}</div>
        </div>
      </form>
    </section>
  );
}
