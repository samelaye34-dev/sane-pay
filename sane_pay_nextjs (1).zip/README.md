# Sane-Pay — Next.js starter (Frontend + Backend)

This repository is a ready-to-deploy Next.js app for **Sane-Pay** (payments storefront + API routes). It's configured with Tailwind CSS and includes API routes for:

- `POST /api/contact` — contact form (sends email via SMTP / Nodemailer).
- `POST /api/create-checkout` — creates checkout session for Stripe, Paystack or Flutterwave and returns a payment URL.

## What I wired for you
- Customer service email (default): santiagocolam3@gmail.com
- Owner email (default): solomonazubuike11@gmail.com
- Customer service phone (default): +2349039950429

These values are used from environment variables when deployed; defaults are present for local testing.

## Quick start (local)
1. Install deps:
```bash
cd sane_pay_nextjs
npm install
```

2. Create a `.env.local` file (see `.env.example`) and fill in your keys and SMTP credentials.

3. Run development server:
```bash
npm run dev
# open http://localhost:3000
```

## Deploying to Vercel (recommended)
1. Create a GitHub repo, push this project.
2. Sign up at https://vercel.com and import the repo.
3. In Vercel dashboard, set environment variables (see `.env.example`).
4. Deploy. After deployment you will get a URL like `https://your-app.vercel.app`.

## Environment variables (.env.local)
See `.env.example`. Important ones include:
- STRIPE_SECRET_KEY
- PAYSTACK_SECRET_KEY
- FLUTTERWAVE_SECRET_KEY
- SMTP_USER, SMTP_PASS (for contact form)
- CUSTOMER_SERVICE_EMAIL, OWNER_EMAIL
- BASE_URL (optional; set to your deployed URL)

## Notes & next steps
- For production email delivery consider SendGrid/Mailgun/Sendinblue instead of raw SMTP.
- For SMS notifications consider Twilio or Africa's Talking.
- Secure webhook endpoints from payment providers and verify signatures before fulfilling orders.

If you want, I can walk you through the Vercel deploy step-by-step once you upload the project.
